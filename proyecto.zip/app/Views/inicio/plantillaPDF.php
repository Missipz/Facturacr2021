<h1>Hola soy un html</h1>

<img src="https://jrtec.cl/wp-content/uploads/2020/08/JR-TEC-Logo_Original.png">